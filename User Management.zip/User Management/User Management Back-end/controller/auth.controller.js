const db = require('../models/index')
const config = require('../config/auth.config');

const User = db.user;
const Op = db.Sequelize.Op;
var jwt = require('jsonwebtoken')
var bcrypt = require('bcryptjs');

exports.signUp = (req, res) => {
    const userId = req.body.userId
    const username = req.body.username
    const email = req.body.email
    const userType = req.body.userType
    const password = bcrypt.hashSync(req.body.password, 8)
    if (!userId) {
        return res.status(401).send({
            message: "userId can't be empty"
        })
    }
    if (!username) {
        return res.status(401).send({
            message: "username can't be empty"
        })
    }
    if (!password) {
        return res.status(401).send({
            message: "password can't be empty"
        })
    }
    if (!userType) {
        return res.status(401).send({
            message: "userType can't be empty"
        })
    }
    if(!email){
        return res.status(401).send({
            message: "email can't be empty"
        })
    }
        User.create({
            userId: userId,
            username: username,
            email: email,
            userType: userType,
            password: password
        })

            .then(user => {

                res.status(200).send({
                    message: "User Registration successfully!!!"
                })
            })
            .catch(err => {
                res.status(500).send({
                    message: "Some internale error occured" + err.message
                })
            })
    }

    exports.signIn = (req, res) => {
        User.findOne({
            where: {
                email: req.body.email
            }
        })
            .then(user => {
                if (!user) {
                    return res.status(404).send({
                        message: "User Not Found"
                    })
                }
                var passwordIsValid = bcrypt.compareSync(req.body.password, user.password);
                if (!passwordIsValid) {
                    return res.status(401).send({
                        message: "Invalid Password"
                    })
                }
                var token = jwt.sign({ userId: user.userId }, config.secret, {
                    expiresIn: 86400
                })
                res.status(200).send({
                    userId: user.userId,
                    username: user.username,
                    email: user.email,
                    userType: user.userType,
                    token: token
                })

            })
            .catch(err => {
                res.status(500).send({
                    message: "Some internal error occured!! " + err
                })
            })
    }