const db = require('../models/index');
const User = db.user;
const Op = db.Sequelize.Op;
const bcrypt = require('bcryptjs');


exports.findAll = (req, res) => {
    let promise
    promise = User.findAll();
    promise
        .then(data => res.status(200).send(data))
        .catch(err => res.status(500).send({
            message: "Some internal error " + err
        }))
}

exports.update = (req, res) => {
    const users = {
        username: req.body.username,
        password: bcrypt.hashSync(req.body.password, 8),
    }
    const userId = req.params.id;
    User.update(users, {
        where: {
            userId: userId
        }
    })
        .then(user => {
            User.findByPk(userId)
                .then(users => {
                    res.status(200).send(users);
                })
                .catch(err => {
                    res.status(500).send({
                        message: "Some internal error while fetching the category based on id"
                    })
                })
        })
        .catch(err => {
            res.status(500).send({
                message: "some internal error" + err
            })
        })
}

exports.delete = (req, res) => {
    const userId = req.params.id;
    User.destroy({
        where: {
            userId: userId
        }
    })
        .then(user => {
            if (!user) {
                return res.status(404).send({
                    message: "User not found"
                })
            }
            res.status(200).send({
                message: "User Delete Successfully"
            })
        })
        .catch(err => {
            res.status(500).send({
                message: "some internal error" + err
            })
        })
}

exports.findOne = (req, res) => {
    const id = req.params.id;
    User.findByPk(id)
        .then(user => {
            if (!user) {
                return res.status(400).send({
                    message: "User not found"
                })
            }
            res.status(200).send({
                user
            })
        })
        .catch(err => {
            res.status(500).send({
                message: "some internal error" + err
            })
        })
}

exports.create = (req, res) => {

    const userId = req.body.userId;
    const username = req.body.username;
    const password = req.body.password;
    const userType = req.body.userType;
    const email = req.body.email;
    if (!userId) {
        return res.status(401).send({
            message: "userId can't be empty"
        })
    }
    if (!username) {
        return res.status(401).send({
            message: "username can't be empty"
        })
    }
    if (!password) {
        return res.status(401).send({
            message: "password can't be empty"
        })
    }
    if (!userType) {
        return res.status(401).send({
            message: "userType can't be empty"
        })
    }
    if (!email) {
        return res.status(401).send({
            message: "email can't be empty"
        })
    }
    User.create({
        userId: userId,
        username: username,
        email: email,
        password: password,
        userType: userType
    })
        .then(user => {
            return res.status(200).send(user)
        })
        .catch(err => {
            return res.status(500).send({
                message: "some internal error occured", err
            })
        })


}