const jwt=require('jsonwebtoken');
const config=require('../config/auth.config')
const db=require('../models/index')
const User=db.user;

verifyToken=(req,res,next)=>{
    let token=req.headers["x-access-token"];
    if(!token){
        return res.status(402).send({
            message:"No token provided"
        })
    }
    jwt.verify(token,config.secret,(err,decoded)=>{
        if(err){
            return res.status(401).send({
                message:"unathorised"
            })
        }
        req.userId=decoded.userId;
        console.log(decoded)
        next();
    })
}
isAdmin=(req,res,next)=>{
    User.findByPk(req.userId)
    .then(user=>{
        console.log(user)
        if(user.userType=="admin" || user.userType=="ADMIN"){
            next();
            return;
        }
        res.status(403).send({
            message:"Access Denied"
        })
        return;
    })
}

const authJwt={
  verifyToken:verifyToken,
  isAdmin:isAdmin
}

module.exports=authJwt;