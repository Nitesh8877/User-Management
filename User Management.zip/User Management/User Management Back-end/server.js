const express=require('express')
const app=express();
const bodyParser=require('body-parser');
const cors=require('cors')
app.use(bodyParser.urlencoded({extended:true}))
app.use(express.json());
app.use(cors())

// const db=require('./models/index')
// const User=db.user;
// db.connectDB.sync({force:true})
const signUp=require('./routes/auth.routes')
signUp(app);
require('./routes/manage.routes')(app)


app.listen(3020,()=>{
    console.log("Server started successful port number: 3020");

})

