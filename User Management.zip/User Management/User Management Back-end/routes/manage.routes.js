
const auth=require('../middaleware/verifyJwt');
const manage=require('../controller/management.controller')
module.exports=function(app){
    app.get("/cointab/users/",[auth.verifyToken,auth.isAdmin], manage.findAll)
    app.get("/cointab/users/:id",[auth.verifyToken,auth.isAdmin],manage.findOne);
    app.delete("/cointab/users/:id",[auth.verifyToken,auth.isAdmin], manage.delete);
    app.put("/cointab/users/:id",[auth.verifyToken,auth.isAdmin],manage.update);
    app.post("/cointab/users/added",[auth.verifyToken,auth.isAdmin],manage.create);
}

6432