
const controller=require('../controller/auth.controller');
const auth=require('../middaleware/verifyJwt');

module.exports=function(app){
    app.post("/cointab/signup/",controller.signUp)
    app.post("/cointab/signIn",controller.signIn);
   
}