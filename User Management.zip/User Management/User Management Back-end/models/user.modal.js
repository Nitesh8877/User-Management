
module.exports=(sequelize,Sequelize)=>{

    const User=sequelize.define("users",{
        userId:{
            type:Sequelize.STRING,
            primaryKey:true,
        },
        username:{
            type:Sequelize.STRING,
            allowNull:false,
        },
        email:{
            type:Sequelize.STRING,
            allowNull:false,
            unique:true,
        }
        ,
        password:{
            type:Sequelize.STRING,
            allowNull:false
        },
        userType:{
            type:Sequelize.STRING,
            allowNull:false
        }
    });
    return User;

}