const config = require('../config/db.config');
const Sequelize = require('sequelize');

const connectDB = new Sequelize(
    config.DB,
    config.USER, config.PASSWORD,
    {
        host: config.HOST,
        dialect: config.dialect
    }
)

const db = {

}
db.Sequelize = Sequelize;
db.connectDB = connectDB;

db.user = require('./user.modal')(db.connectDB, db.Sequelize)

module.exports = db;